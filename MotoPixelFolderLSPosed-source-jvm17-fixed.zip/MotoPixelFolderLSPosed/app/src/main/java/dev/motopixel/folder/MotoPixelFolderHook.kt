package dev.motopixel.folder

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * Experimental starting point. Moto's APK includes fullscreen folder resources,
 * but the exact runtime view hierarchy must be verified on the target ROM.
 * This hook deliberately avoids replacing launcher logic or intercepting app launches.
 */
class MotoPixelFolderHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.motorola.launcher3") return

        val candidates = listOf(
            "com.android.launcher3.folder.Folder",
            "com.android.launcher3.folder.FolderPagedView"
        )

        for (className in candidates) {
            try {
                val clazz = XposedHelpers.findClass(className, lpparam.classLoader)
                XposedBridge.hookAllMethods(clazz, "onFinishInflate", object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val view = param.thisObject as? View ?: return
                        applyExperimentalCard(view)
                    }
                })
                XposedBridge.log("MotoPixelFolder: hooked $className")
            } catch (_: Throwable) {
                // Class/method may not exist in this launcher build; continue probing.
            }
        }
        XposedBridge.log("MotoPixelFolder: loaded for ${lpparam.packageName}")
    }

    private fun applyExperimentalCard(view: View) {
        try {
            // Cosmetic fallback only: actual fullscreen-to-popup conversion requires
            // confirmed parent/window layout handling for this exact Moto build.
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(view, 28f)
                setColor(Color.argb(242, 32, 32, 36))
            }
            view.background = bg
            view.clipToOutline = true

            val lp = view.layoutParams
            if (lp is FrameLayout.LayoutParams) {
                // Avoid forcing width/height until parent and screen insets are known.
                lp.gravity = Gravity.CENTER
                view.layoutParams = lp
            }
        } catch (t: Throwable) {
            XposedBridge.log("MotoPixelFolder: styling failed: $t")
        }
    }

    private fun dp(view: View, value: Float): Float =
        value * view.resources.displayMetrics.density
}
